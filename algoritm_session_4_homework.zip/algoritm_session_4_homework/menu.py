







menu = """
welcome to elias restaurant

1.cafe
    1.late          250 T
    2.tea           150 T
    3.nescafe       200 T
    4.cake          300 T
2.restaurant
    1.kebab         600 T
    2.ghorme        400 T
    3.goge          500 T
    4.cholo         250 T
3.bar               
    1.beer          500 T
    2.wine          700 T
    3.coctail       600 T
    4.whiskey       550 T
4.fastfood          
    1.pizza         700 T
    2.pasta         400 T
    3.lasagna       450 T
    4.burger        600 T
5.game boards       
    1.chess         150 T
    2.backgammon    100 T
    3.darts         200 T
    4.passover      100 T
                    
"""
print(menu)



price = 0


while True:

    person_choice_part = input("""
    enter 
    *1* for cafe
    *2* for restaurant
    *3* for bar
    *4* for fastfood
    *5* for gameboards
    *6* for exit
    your choice:""")
    while True:
        match person_choice_part:
            case "1":
                cafe_menu = input("""
    enter a number
    1.late          250 T
    2.tea           150 T
    3.nescafe       200 T
    4.cake          300 T
    5.exit
    choose your order:""")
                match cafe_menu:
                    case "1":
                        num = int(input("""
    how many?"""))
                        tax = 250 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "2":
                        num = int(input("""
    how many?"""))
                        tax = 150 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "3":
                        num = int(input("""
    how many?"""))
                        tax = 200 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "4":
                        num = int(input("""
    how many?"""))
                        tax = 300 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case _:
                        break
            case "2":
                restaurant_menu = input("""
    enter a number
    1.kebab         600 T
    2.ghorme        400 T
    3.goge          500 T
    4.cholo         250 T
    5.exit
    choose your order:""")
                match restaurant_menu:
                    case "1":
                        num = int(input("""
    how many?"""))
                        tax = 600 * num
                        price =+ tax
                        print("you shoud pay:",price)
                    case "2":
                        num = int(input("""
    how many?"""))
                        tax = 400 * num
                        price =+ tax
                        print("you shoud pay:",price)
                    case "3":
                        num = int(input("""
    how many?"""))
                        tax = 500 * num
                        price =+ tax
                        print("you shoud pay:",price)
                    case "4":
                        num = int(input("""
    how many?"""))
                        tax = 250 * num
                        price =+ tax
                        print("you shoud pay:",price)
                    case _:
                        break
            case "3":
                bar_menu = input("""
    enter a number
    1.beer          500 T
    2.wine          700 T
    3.coctail       600 T
    4.whiskey       550 T
    5.exit
    choose your order:""")
                match bar_menu:
                    case "1":
                        num = int(input("""
    how many?"""))
                        tax = 500 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "2":
                        num = int(input("""
    how many?"""))
                        tax = 700 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "3":
                        num = int(input("""
    how many?"""))
                        tax = 600 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "4":
                        num = int(input("""
    how many?"""))
                        tax = 550 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case _:
                        break
            case "4":
                fastfood_menu = input("""
    enter a number
    1.pizza         700 T
    2.pasta         400 T
    3.lasagna       450 T
    4.burger        600 T
    5.exit
    choose your order:""")
                match fastfood_menu:
                    case "1":
                        num = int(input("""
    how many?"""))
                        tax = 700 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "2":
                        num = int(input("""
    how many?"""))
                        tax = 400 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "3":
                        num = int(input("""
    how many?"""))
                        tax = 450 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "4":
                        num = int(input("""
    how many?"""))
                        tax = 600 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case _:
                        break
            case "5":
                game_boards_menu = input("""
    enter a number
    1.chess         150 T
    2.backgammon    100 T
    3.darts         200 T
    4.passover      100 T
    5.exit
    choose your order:""")
                match game_boards_menu:
                    case "1":
                        num = int(input("""
    how many?"""))
                        tax = 150 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "2":
                        num = int(input("""
    how many?"""))
                        tax = 100 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "3":
                        num = int(input("""
    how many?"""))
                        tax = 200 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case "4":
                        num = int(input("""
    how many?"""))
                        tax = 100 * num
                        price =+ tax
                        print("""
    you shoud pay:""",price)
                    case _:
                         break
            case _:
                print("""
    goodbye""")
                break